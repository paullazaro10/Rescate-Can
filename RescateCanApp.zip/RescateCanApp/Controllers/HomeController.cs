﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RescateCanApp.Models;
using RescateCanApp.Datos;
using Microsoft.EntityFrameworkCore;

namespace RescateCanApp.Controllers
{
    public class HomeController : Controller
    {
        private MascotaContext _context;

        public HomeController(MascotaContext c){ //Indica al mvc que mascotacontext es el puente con la base de datos
            _context = c;
        }
        // Listado de mascotas
        public IActionResult Index(int tipomascota, int edadmascota, int sexomascota)
        {
        
            ViewBag.Tipos = _context.Tipos.ToList();
            ViewBag.Edad = _context.Edad.ToList();
            ViewBag.Sexo = _context.Sexo.ToList();

            //mostrar todas las mascotas
            var mascotas = _context.Mascotas.Include(x=> x.Tipo).Include(x=> x.Edad).Include(x=> x.Sexo).ToList();

            
            //mostrar las mascotas cuando usemos todos los filtros
                if(tipomascota !=0 & edadmascota !=0 & sexomascota != 0 ){
                mascotas = _context.Mascotas.Include(x=>x.Tipo)
                .Include(x=>x.Edad).Include(x=>x.Sexo)
            //El enlace entre el tipo y las mascotas
                .Where(x=> x.TipoId == tipomascota)
                .Where(x=> x.EdadId == edadmascota).Where(x=> x.SexoId == sexomascota).ToList();
                }else{
                    if(tipomascota !=0 & edadmascota !=0){
                        mascotas = _context.Mascotas.Include(x=>x.Tipo).Include(x=>x.Edad)
                        .Where(x=> x.TipoId == tipomascota).Where(x=> x.EdadId == edadmascota).ToList();   
                    }
                    if(edadmascota !=0 & sexomascota !=0){
                    mascotas = _context.Mascotas.Include(x=>x.Edad).Include(x=>x.Sexo)
                    .Where(x=> x.EdadId == edadmascota).Where(x=> x.SexoId == sexomascota).ToList();
                    }
                    if(tipomascota !=0 & sexomascota !=0){
                    mascotas = _context.Mascotas.Include(x=>x.Tipo).Include(x=>x.Sexo)
                    .Where(x=> x.TipoId == tipomascota).Where(x=> x.SexoId == sexomascota).ToList();
                    }else{
                         if(tipomascota !=0){
                        mascotas = _context.Mascotas.Include(x=>x.Tipo)
                        .Where(x=> x.TipoId == tipomascota).ToList();   
                    }
                    if(edadmascota !=0){
                    mascotas = _context.Mascotas.Include(x=>x.Edad)
                    .Where(x=> x.EdadId == edadmascota).ToList();
                    }
                    if(sexomascota !=0){
                    mascotas = _context.Mascotas.Include(x=>x.Sexo)
                    .Where(x=> x.SexoId == sexomascota).ToList();

                    }
                    }
                    
                }
                
                    
            //El enlace eintre el tipo y las mascotas

            return View(mascotas);
        }

        

        // Formulario de ingreso de mascotas
        public IActionResult Registro()
        {
            //necesario para imprimir Tipos de la BD
            //con los atributos de TipoMascota
            ViewBag.Tipos = _context.Tipos.ToList();
            ViewBag.Edad = _context.Edad.ToList();
            ViewBag.Sexo = _context.Sexo.ToList();
            return View();
        }
        //recibe Mascota
        
        [HttpPost]
        public IActionResult Registro(Mascota m)
        {
            if(ModelState.IsValid){
                //añadir la mascota a la BD, a la tabla con los mismo atributos 
                _context.Add(m);
                //guardarlos
                _context.SaveChanges();
                //redireccionar a index

                return RedirectToAction("index");
            }

            return View(m);
        }
        
        public IActionResult Informacion(int id)
        {
            var p = _context.Mascotas.Include(x=> x.Tipo).Include(x=> x.Edad).Include(x=> x.Sexo)
            .Where(x=> x.Id == id).ToList();
            return View(p);
        }
        
        
        public IActionResult Actualizar(int id)
        {
            ViewBag.Tipos = _context.Tipos.ToList();
            ViewBag.Edad = _context.Edad.ToList();
            ViewBag.Sexo = _context.Sexo.ToList();
            //si no colocaba los include no me actualiza los tipos edades y sexo
            var p = _context.Mascotas.Include(x=> x.Tipo).Include(x=> x.Edad).Include(x=> x.Sexo).FirstOrDefault(x => x.Id == id);

            if (p == null) {
                return NotFound();
            }

            return View(p);
        }

        [HttpPost]
        public IActionResult Actualizar(Mascota p)
        {
            if (ModelState.IsValid) {
                var MascotaBd = _context.Mascotas.Find(p.Id);

                MascotaBd.NombreTemporal = p.NombreTemporal;
                MascotaBd.Foto = p.Foto;
                MascotaBd.EdadId = p.EdadId;
                MascotaBd.TipoId= p.TipoId;
                MascotaBd.SexoId = p.SexoId;

                _context.SaveChanges();

                return RedirectToAction("index");
            }

            return View(p);
        }
         public IActionResult Borrar(int id)
        {
            var p = _context.Mascotas.FirstOrDefault(x => x.Id == id);

            if (p != null) {
                _context.Mascotas.Remove(p);
                _context.SaveChanges();
            }

            return RedirectToAction("index");
        }
        
    }
}
