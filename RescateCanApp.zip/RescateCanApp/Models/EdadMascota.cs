using System.Collections.Generic;

namespace RescateCanApp.Models
{
    public class EdadMascota
    {
        public int Id { get; set; }
        public int Edad { get; set; }
        public List<Mascota> Mascotas { get; set; }
    }
}