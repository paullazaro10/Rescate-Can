namespace RescateCanApp.Models
{
    public class Mascota
    {
        public int Id { get; set; }

        public string NombreTemporal { get; set; }
        public int EdadId { get; set; }
        public TipoMascota Tipo { get; set; }
        public string Foto { get; set; }
        public int TipoId { get; set; }
        public EdadMascota Edad { get; set; }
        public SexoMascota  Sexo { get; set; }
        public int SexoId { get; set; }
    }
}