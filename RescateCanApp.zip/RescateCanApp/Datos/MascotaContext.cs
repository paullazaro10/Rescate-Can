using RescateCanApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace RescateCanApp.Datos
{
    public class MascotaContext : IdentityDbContext
    {
        public DbSet<Mascota> Mascotas { get; set; }
        public DbSet<TipoMascota> Tipos { get; set; }
        public DbSet<EdadMascota> Edad { get; set; }
        public DbSet<SexoMascota> Sexo {get; set;}

        public MascotaContext(DbContextOptions<MascotaContext> o ): base(o){

        }
    }
}